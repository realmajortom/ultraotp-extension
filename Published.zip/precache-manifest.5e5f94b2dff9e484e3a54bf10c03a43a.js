self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0e31b4c07a8d799035de30d5aab80f4a",
    "url": "/index.html"
  },
  {
    "revision": "30c68f99b5882bd579bb",
    "url": "/static/css/main.c94810b6.chunk.css"
  },
  {
    "revision": "8310206ba164788640b0",
    "url": "/static/js/2.59cbf46f.chunk.js"
  },
  {
    "revision": "321d5d46da54922ec27f7f78856d2a39",
    "url": "/static/js/2.59cbf46f.chunk.js.LICENSE"
  },
  {
    "revision": "30c68f99b5882bd579bb",
    "url": "/static/js/main.4e0b1202.chunk.js"
  },
  {
    "revision": "a232a10c865a9eb4a435",
    "url": "/static/js/runtime-main.72af4ec0.js"
  },
  {
    "revision": "40a53849a29e060686619a19237066d5",
    "url": "/static/media/Manrope-Bold.40a53849.woff2"
  },
  {
    "revision": "8f960c59075a2ee98f96df94aaf1f2a5",
    "url": "/static/media/Manrope-ExtraBold.8f960c59.woff2"
  },
  {
    "revision": "2557cb624f9cc8639a82b3212a1c8100",
    "url": "/static/media/Manrope-ExtraLight.2557cb62.woff2"
  },
  {
    "revision": "9aa133c630cd26e7bebc2ea9803d4113",
    "url": "/static/media/Manrope-Light.9aa133c6.woff2"
  },
  {
    "revision": "d484e4d389b71f875ca186f6ecd19816",
    "url": "/static/media/Manrope-Medium.d484e4d3.woff2"
  },
  {
    "revision": "1b6a58036590640a5d7050ddab7e38ec",
    "url": "/static/media/Manrope-Regular.1b6a5803.woff2"
  },
  {
    "revision": "46cd7793d53e53f36707119b96f10957",
    "url": "/static/media/Manrope-SemiBold.46cd7793.woff2"
  },
  {
    "revision": "7cfbd4284ec01b7ace2f8edb5cddae84",
    "url": "/static/media/RobotoMono-Medium.7cfbd428.ttf"
  }
]);