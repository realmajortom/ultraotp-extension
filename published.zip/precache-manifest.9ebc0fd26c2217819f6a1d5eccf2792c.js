self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d2da5e920812e3978a9a9f55c53d6c80",
    "url": "/index.html"
  },
  {
    "revision": "2abcefa468e9528686dc",
    "url": "/static/css/main.241a6955.chunk.css"
  },
  {
    "revision": "dbc966505f77e2929251",
    "url": "/static/js/2.175a2329.chunk.js"
  },
  {
    "revision": "0824a3f98374bdf93e5634141928a978",
    "url": "/static/js/2.175a2329.chunk.js.LICENSE"
  },
  {
    "revision": "2abcefa468e9528686dc",
    "url": "/static/js/main.13f355dd.chunk.js"
  },
  {
    "revision": "c61009fb4cf7797d2b32",
    "url": "/static/js/runtime-main.38593302.js"
  },
  {
    "revision": "40a53849a29e060686619a19237066d5",
    "url": "/static/media/Manrope-Bold.40a53849.woff2"
  },
  {
    "revision": "8f960c59075a2ee98f96df94aaf1f2a5",
    "url": "/static/media/Manrope-ExtraBold.8f960c59.woff2"
  },
  {
    "revision": "d484e4d389b71f875ca186f6ecd19816",
    "url": "/static/media/Manrope-Medium.d484e4d3.woff2"
  },
  {
    "revision": "1b6a58036590640a5d7050ddab7e38ec",
    "url": "/static/media/Manrope-Regular.1b6a5803.woff2"
  },
  {
    "revision": "46cd7793d53e53f36707119b96f10957",
    "url": "/static/media/Manrope-SemiBold.46cd7793.woff2"
  }
]);